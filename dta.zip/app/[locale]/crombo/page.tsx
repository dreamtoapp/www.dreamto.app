"use client";
import { useState, useEffect } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import dynamic from "next/dynamic";
import { useLocale } from "next-intl";
import Text from "../../../components/Text";

const LaunchPage = () => {
  const targetDate = new Date("2025-03-01T00:00:00").getTime();
  const [timeLeft, setTimeLeft] = useState(0);
  const locale = useLocale();

  useEffect(() => {
    if (typeof window !== "undefined") {
      setTimeLeft(targetDate - new Date().getTime());
      const interval = setInterval(() => {
        setTimeLeft(targetDate - new Date().getTime());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [targetDate]);

  const formatTime = (ms: number) => {
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / 1000 / 60) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-100 to-blue-900 text-white p-6 w-full">
      <Card className="w-full max-w-4xl p-10 text-center bg-gradient-to-b from-blue-100 to-blue-900 text-gray-900 rounded-3xl shadow-2xl transform scale-105">
        <CardHeader className=" flex items-center flex-col gap-4">
          <div className=" text-3xl font-bold bg-white text-blue-600 px-6 py-3 rounded-xl shadow-md">
            <Text variant="p" locale={locale} cairoFont>
              ينتهي العرض خلال
            </Text>{" "}
            {formatTime(timeLeft)}
          </div>
          <CardTitle className="text-5xl font-extrabold text-blue-700">
            <Text variant="h1" locale={locale} cairoFont>
              🚀 ارتقِ بخدمة العملاء مع كرمبو!
            </Text>
          </CardTitle>
          <CardDescription className="text-xl font-medium text-gray-800 mt-2">
            <Text variant="h4" locale={locale} cairoFont>
              منصة ذكية تجعل التواصل مع عملائك أكثر سهولة واحترافية.
            </Text>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Image
            src="/assets/homepage/crombo.png"
            alt="Try Karambo"
            width={100}
            height={350}
            className="mx-auto rounded-xl mb-6"
          />
          <ul className="mt-6 text-left text-lg text-gray-700 space-y-2">
            <li className="flex items-center gap-3">
              <span className="text-blue-600 font-bold text-2xl">✔</span>{" "}
              <Text variant="span" locale={locale} cairoFont>
                منصة ذكية تجعل التواصل مع عملائك أكثر سهولة واحترافية.
              </Text>
            </li>
            <li className="flex items-center gap-3">
              <span className="text-blue-600 font-bold text-2xl">✔</span> تحليل
              <Text variant="span" locale={locale} cairoFont>
                المشاعر وتحسين تجربة العملاء
              </Text>
            </li>
            <li className="flex items-center gap-3">
              <span className="text-blue-600 font-bold text-2xl">✔</span> تكامل
              <Text variant="span" locale={locale} cairoFont>
                سهل مع أنظمة الـ CRM
              </Text>
            </li>
          </ul>
          <form className="mt-8 flex flex-col gap-6 items-center">
            <Input
              type="email"
              placeholder="أدخل بريدك الإلكتروني"
              className="text-lg w-3/4 p-3 rounded-lg border-2 border-blue-500"
              required
            />
            <Button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white py-4 px-10 text-lg font-bold rounded-xl shadow-lg transform hover:scale-105 transition"
            >
              <Text variant="span" locale={locale} cairoFont>
                احصل على نسختك المجانية الآن
              </Text>
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default dynamic(() => Promise.resolve(LaunchPage), { ssr: false });
